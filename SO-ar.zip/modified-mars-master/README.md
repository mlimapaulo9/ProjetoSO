# modified-mars
MARS (MIPS Assembler and Runtime Simulator) modificado para fins da disciplina de Sistema Operacionais do curso de Ciência da Computação da UFERSA
